// ALERT // 

var paragraph= "Written";
	if ("Written") {
		window.alert ("Be sure to read the important information on Jaguars below");
	}
	else {
		window.alert ("Be sure to stay up to date with information on Jaguar endagerment");
	}

